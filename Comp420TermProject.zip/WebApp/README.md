# COMP 420 Term Project

## By Primo Tiongco and Darrell Wulff

### Install and run instructions
- Program uses Python 3.7 - 3.9
- Recommend to setup a virtual environment: https://docs.python.org/3/library/venv.html
- For program dependencies use this command to install after setting up virtual environment( or without the envirmonent): pip install -r requirements.txt
- Got into terminal, got to the directory where main.py is located
- To run in terminal: python3 main.py
- Or for windows: python main.py